from models import init_db

init_db()
print("✅ Local database initialized.")
